public interface Information { 
    public String getMSG();
}
