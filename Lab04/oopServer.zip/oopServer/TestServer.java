class TestServer extends VisualServer 
    implements Information {

    public TestServer(int s, StudentDB u) {
	super(s, u); 
    }

}